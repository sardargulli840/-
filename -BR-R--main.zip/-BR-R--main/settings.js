
module.exports = {
  SESSION_ID: "",  // add session Id here
  
  OWNER_NUMBER: "923427582273", // add owner number 
  
  PREFIX: ".", // prefix (e.g., ., /, !, *)
  
  TIMEZONE: "Asia/Karachi" // put your country timeZone....leave blank if u don't know.
};

